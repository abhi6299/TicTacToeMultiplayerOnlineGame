package com.example.tictactoemultiplayeronlinegame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText etInviteEMail;
    EditText etMyEmail;
    Button buLogin;
    //int chances;

    //Firebase
    private FirebaseAnalytics mFirebaseAnalytics;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    String MyEmail;
    String uid;
    // Write a message to the database
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();

    private Handler mHandler =new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etInviteEMail=(EditText)findViewById(R.id.etInviteEmail);
        etMyEmail=(EditText)findViewById(R.id.etMyEmail);
        buLogin=(Button)findViewById(R.id.Login);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            public static final String TAG = "Login";

            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    uid= user.getUid();
                    Log.d(TAG, "onAuthStateChanged:signed_in:" +uid);
                    MyEmail=user.getEmail();
                    buLogin.setEnabled(false);
                    etMyEmail.setText(MyEmail);

                    myRef.child("Users").child(BeforeAt(MyEmail)).child("Request").setValue(uid);
                    IncommingRequest();
                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
                // ...
            }
        };
    }

    String BeforeAt(String Email){
        String[] split= Email.split("@");
        return split[0];
    }

    //Login
    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    void UserLogin(String email, String password){
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    public static final String TAG ="Register" ;

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Log.d(TAG, "createUserWithEmail:onComplete:" + task.isSuccessful());

                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Login fail",Toast.LENGTH_SHORT).show();
                        }

                        // ...
                    }
                });
    }

    public void BuInvite(View view) {
        Log.d("Invate",etInviteEMail.getText().toString());
        myRef.child("Users")
                .child(BeforeAt(etInviteEMail.getText().toString())).child("Request").push().setValue(MyEmail);

        // Jena //Laya  ="Laya:Jena"
        StartGame(BeforeAt(etInviteEMail.getText().toString()) +":"+ BeforeAt(MyEmail));
        MySample="X";

    }
    void IncommingRequest(){

        // Read from the database
        myRef.child("Users").child(BeforeAt(MyEmail)).child("Request")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        try{
                            HashMap<String,Object> td=(HashMap<String,Object>) dataSnapshot.getValue();
                            if (td!=null){

                                String value;
                                for(String key:td.keySet()){
                                    value=(String) td.get(key);
                                    Log.d("User request",value);
                                    etInviteEMail.setText(value);
                                    ButtonColor();
                                    myRef.child("Users").child(BeforeAt(MyEmail)).child("Request").setValue(uid);
                                    break;
                                }
                            }

                        }catch (Exception ex){}
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {

                    }
                });

    }
    void ButtonColor(){
        etInviteEMail.setBackgroundColor(Color.RED);
    }

    public void BuAccept(View view) {
        Log.d("Accept",etInviteEMail.getText().toString());
        myRef.child("Users")
                .child(BeforeAt(etInviteEMail.getText().toString())).child("Request").push().setValue(MyEmail);
        //Laya// Jena  ="Laya:Jena"
        StartGame(BeforeAt( BeforeAt(MyEmail) + ":"+ etInviteEMail.getText().toString()) );
        MySample="O";
    }

    // PlayerGameID= "Laya:Jena"

    String PlayerSession="";

    String MySample="X";
    void StartGame(String PlayerGameID){
        PlayerSession=PlayerGameID;
        //chances=0;
        //TODO: implement later
        myRef.child("Playing").child(PlayerGameID).removeValue();


        // Read from the database
        myRef.child("Playing").child(PlayerGameID)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        try{
                            Player1.clear();
                            Player2.clear();
                            ActivePlayer=2;
                            HashMap<String,Object> td=(HashMap<String,Object>) dataSnapshot.getValue();
                            if (td!=null){

                                String value;

                                for(String key:td.keySet()){
                                    value=(String) td.get(key);
                                    if(!value.equals(BeforeAt(MyEmail)))
                                        ActivePlayer=MySample=="X"?1:2;
                                    else
                                        ActivePlayer=MySample=="X"?2:1;

                                    String[] splitID= key.split(":");
                                    AutoPlay(Integer.parseInt(splitID[1]));

                                }
                            }


                        }catch (Exception ex){}
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {

                    }
                });
    }

    private Runnable mRunnable =new Runnable() {
        @Override
        public void run() {
            whenDone();
        }
    };
    void whenDone()
    {
        //chances=0;
        for(int i=1;i<=9;i++) {
            switch (i) {
                case 1:
                    Button SelectedButton1 = (Button) findViewById(R.id.Button1);
                    SelectedButton1.setBackgroundColor(Color.WHITE);
                    SelectedButton1.setEnabled(true);
                    SelectedButton1.setText("1");
                    break;
                case 2:
                    Button SelectedButton2 = (Button) findViewById(R.id.Button2);
                    SelectedButton2.setBackgroundColor(Color.WHITE);
                    SelectedButton2.setEnabled(true);
                    SelectedButton2.setText("2");
                    break;
                case 3:
                    Button SelectedButton3 = (Button) findViewById(R.id.Button3);
                    SelectedButton3.setBackgroundColor(Color.WHITE);
                    SelectedButton3.setEnabled(true);
                    SelectedButton3.setText("3");
                    break;
                case 4:
                    Button SelectedButton4 = (Button) findViewById(R.id.Button4);
                    SelectedButton4.setBackgroundColor(Color.WHITE);
                    SelectedButton4.setEnabled(true);
                    SelectedButton4.setText("4");
                    break;
                case 5:
                    Button SelectedButton5 = (Button) findViewById(R.id.Button5);
                    SelectedButton5.setBackgroundColor(Color.WHITE);
                    SelectedButton5.setEnabled(true);
                    SelectedButton5.setText("5");
                    break;
                case 6:
                    Button SelectedButton6 = (Button) findViewById(R.id.Button6);
                    SelectedButton6.setBackgroundColor(Color.WHITE);
                    SelectedButton6.setEnabled(true);
                    SelectedButton6.setText("6");
                    break;
                case 7:
                    Button SelectedButton7 = (Button) findViewById(R.id.Button7);
                    SelectedButton7.setBackgroundColor(Color.WHITE);
                    SelectedButton7.setEnabled(true);
                    SelectedButton7.setText("7");
                    break;
                case 8:
                    Button SelectedButton8 = (Button) findViewById(R.id.Button8);
                    SelectedButton8.setBackgroundColor(Color.WHITE);
                    SelectedButton8.setEnabled(true);
                    SelectedButton8.setText("8");
                    break;
                case 9:
                    Button SelectedButton9 = (Button) findViewById(R.id.Button9);
                    SelectedButton9.setBackgroundColor(Color.WHITE);
                    SelectedButton9.setEnabled(true);
                    SelectedButton9.setText("9");
                    break;
                default:
                    Button SelectedButton10 = (Button) findViewById(R.id.Button3);
                    SelectedButton10.setBackgroundColor(Color.WHITE);
                    break;
            }
        }
        Player1.clear();
        Player2.clear();
        //Empty.clear();
    }

    public void BuLogin(View view) {
        // Log.d("Login",etMyEmail.getText().toString());
        UserLogin(etMyEmail.getText().toString(),"hussein");
    }

    public void buClick(View view) {
        // game not started yet
        if (PlayerSession.length()<=0)
            return;

        Button buSelected= (Button) view;
        int CellID=0;
        switch ((buSelected.getId())){

            case R.id.Button1:
                CellID=1;
                break;

            case R.id.Button2:
                CellID=2;
                break;

            case R.id.Button3:
                CellID=3;
                break;

            case R.id.Button4:
                CellID=4;
                break;

            case R.id.Button5:
                CellID=5;
                break;

            case R.id.Button6:
                CellID=6;
                break;

            case R.id.Button7:
                CellID=7;
                break;

            case R.id.Button8:
                CellID=8;
                break;

            case R.id.Button9:
                CellID=9;
                break;
        }



        myRef.child("Playing").child(PlayerSession).child( "CellID:"+CellID).setValue(BeforeAt(MyEmail));




    }


    int ActivePlayer=1; // 1- for first , 2 for second
    ArrayList<Integer> Player1= new ArrayList<Integer>();// hold player 1 data
    ArrayList<Integer> Player2= new ArrayList<Integer>();// hold player 2 data

    void PlayGame(int CellID,Button buSelected){

        Log.d("Player:",String.valueOf(CellID));

        if (ActivePlayer==1){
            buSelected.setText("X");
            buSelected.setBackgroundColor(Color.GREEN);
            Player1.add(CellID);
           // chances++;

        }
        else if (ActivePlayer==2){
            buSelected.setText("O");
            buSelected.setBackgroundColor(Color.BLUE);
            Player2.add(CellID);
          //  chances++;

        }

        buSelected.setEnabled(false);
        CheckWiner();
    }

    void CheckWiner(){

       // if(chances>17)
       // {
        //    Toast.makeText(this, "Draw", Toast.LENGTH_SHORT).show();
        //    mHandler.postDelayed(mRunnable,3000);
       // }

        int Winer=-1;
        //row 1
        if (Player1.contains(1) && Player1.contains(2)  && Player1.contains(3))  {
            Winer=1 ;
        }
        if (Player2.contains(1) && Player2.contains(2)  && Player2.contains(3))  {
            Winer=2 ;
        }

        //row 2
        if (Player1.contains(4) && Player1.contains(5)  && Player1.contains(6))  {
            Winer=1 ;
        }
        if (Player2.contains(4) && Player2.contains(5)  && Player2.contains(6))  {
            Winer=2 ;
        }

        //row 3
        if (Player1.contains(7) && Player1.contains(8)  && Player1.contains(9))  {
            Winer=1 ;
        }
        if (Player2.contains(7) && Player2.contains(8)  && Player2.contains(9))  {
            Winer=2 ;
        }


        //col 1
        if (Player1.contains(1) && Player1.contains(4)  && Player1.contains(7))  {
            Winer=1 ;
        }
        if (Player2.contains(1) && Player2.contains(4)  && Player2.contains(7))  {
            Winer=2 ;
        }

        //col 2
        if (Player1.contains(2) && Player1.contains(5)  && Player1.contains(8))  {
            Winer=1 ;
        }
        if (Player2.contains(2) && Player2.contains(5)  && Player2.contains(8))  {
            Winer=2 ;
        }


        //col 3
        if (Player1.contains(3) && Player1.contains(6)  && Player1.contains(9))  {
            Winer=1 ;
        }
        if (Player2.contains(3) && Player2.contains(6)  && Player2.contains(9))  {
            Winer=2 ;
        }


        if ( Winer !=-1){
            // We have winer

            if (Winer==1){
            //    chances=0;
                Toast.makeText(this,"Player 1 is winner",Toast.LENGTH_LONG).show();
                mHandler.postDelayed(mRunnable,3000);
            }

            if (Winer==2){
            //    chances=0;
                Toast.makeText(this,"Player 2 is winner",Toast.LENGTH_LONG).show();
                mHandler.postDelayed(mRunnable,3000);
            }

        }

    }

    void AutoPlay(int CellID){

        Button buSelected;
        switch (CellID){

            case 1 :
                buSelected=(Button) findViewById(R.id.Button1);
                break;

            case 2:
                buSelected=(Button) findViewById(R.id.Button2);
                break;

            case 3:
                buSelected=(Button) findViewById(R.id.Button3);
                break;

            case 4:
                buSelected=(Button) findViewById(R.id.Button4);
                break;

            case 5:
                buSelected=(Button) findViewById(R.id.Button5);
                break;

            case 6:
                buSelected=(Button) findViewById(R.id.Button6);
                break;

            case 7:
                buSelected=(Button) findViewById(R.id.Button7);
                break;

            case 8:
                buSelected=(Button) findViewById(R.id.Button8);
                break;

            case 9:
                buSelected=(Button) findViewById(R.id.Button9);
                break;
            default:
                buSelected=(Button) findViewById(R.id.Button1);
                break;

        }
        PlayGame(CellID, buSelected);
    }

}

/*
public class MainActivity extends AppCompatActivity {

    private Handler mHandler =new Handler();
    EditText inviteEmail;
    EditText myEmail;
    Button buLogin;
    //Firebase
    private FirebaseAnalytics mFirebaseAnalytics;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    String MyEmail;
    String uid;

    //for database
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inviteEmail=findViewById(R.id.InviteEmail);
        myEmail=findViewById(R.id.myEmail);
        buLogin=findViewById(R.id.Login);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mAuth = FirebaseAuth.getInstance();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            public static final String TAG = "Login";

            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    // User is signed in
                    uid= user.getUid();
                    Log.d(TAG, "onAuthStateChanged:signed_in:" +uid);
                    MyEmail=user.getEmail();
                    buLogin.setEnabled(false);
                    myEmail.setText(MyEmail);

                    myRef.child("Users").child(BeforeAt(MyEmail)).child("Request").setValue(uid);
                    IncommingRequest();
                } else {
                    // User is signed out
                    Log.d(TAG, "onAuthStateChanged:signed_out");
                }
                // ...
            }
        };
    }

    String BeforeAt(String email)
    {
        String[] split=email.split("@");
        return split[0];
    }

    //Login
    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    void UserLogin(String email, String password){
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    public static final String TAG ="Register" ;

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Log.d(TAG, "createUserWithEmail:onComplete:" + task.isSuccessful());

                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Login fail", Toast.LENGTH_SHORT).show();
                        }

                        // ...
                    }
                });
    }

    void IncommingRequest(){

        // Read from the database
        myRef.child("Users").child(BeforeAt(MyEmail)).child("Request")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        try{
                            HashMap<String,Object> td=(HashMap<String,Object>) dataSnapshot.getValue();
                            if (td!=null){

                                String value;
                                for(String key:td.keySet()){
                                    value=(String) td.get(key);
                                    Log.d("User request",value);
                                    inviteEmail.setText(value);
                                    ButtonColor();
                                    myRef.child("Users").child(BeforeAt(MyEmail)).child("Request").setValue(uid);
                                    break;
                                }
                            }

                        }catch (Exception ex){}
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {

                    }
                });

    }

    void ButtonColor(){
        inviteEmail.setBackgroundColor(Color.RED);
    }


    public void buInvite(View view) {

    myRef.child("Users").child(BeforeAt(inviteEmail.getText().toString()))
            .child("Request").push().setValue(myEmail);//push will generate different id every time
        // Jena //Laya  ="Laya:Jena"
        StartGame(BeforeAt(inviteEmail.getText().toString()) +":"+ BeforeAt(MyEmail));
        MySample="X";
    }

    public void buAccept(View view) {
        myRef.child("Users").child(BeforeAt(inviteEmail.getText().toString()))
                .child("Request").push().setValue(myEmail);//push will generate different id every time
        //Laya// Jena  ="Laya:Jena"
        StartGame(BeforeAt( BeforeAt(MyEmail) + ":"+ inviteEmail.getText().toString()) );
        MySample="0";
    }

    public void buLogin(View view) {

    UserLogin(myEmail.getText().toString(),"abhinav");
    }

    String PlayerSession="";
    String MySample="X";
    void StartGame(String PlayerGameId)
    {
        PlayerSession=PlayerGameId;
        myRef.child("Playing").child(PlayerGameId).removeValue();

        // Read from the database
        myRef.child("Playing").child(PlayerGameId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        try{
                            Player1.clear();
                            Player2.clear();
                            ActivePlayer=2;
                            HashMap<String,Object> td=(HashMap<String,Object>) dataSnapshot.getValue();
                            if (td!=null){

                                String value;

                                for(String key:td.keySet()){
                                    value=(String) td.get(key);
                                    if(!value.equals(BeforeAt(MyEmail)))
                                        ActivePlayer=MySample=="X"?1:2;
                                    else
                                        ActivePlayer=MySample=="X"?2:1;

                                    String[] splitID= key.split(":");
                                    AutoPlay(Integer.parseInt(splitID[1]));

                                }
                            }


                        }catch (Exception ex){}
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {

                    }
                });
    }

    public void buClick(View view) {

        if(PlayerSession.length()<=0)
        {
            return;
        }
        Button Selected=(Button)view;
        Selected.setBackgroundColor(Color.RED);
        int CellId=0;
        switch(Selected.getId())
        {
            case R.id.Button1:
                CellId=1;
                break;
            case R.id.Button2:
                CellId=2;
                break;
            case R.id.Button3:
                CellId=3;
                break;
            case R.id.Button4:
                CellId=4;
                break;
            case R.id.Button5:
                CellId=5;
                break;
            case R.id.Button6:
                CellId=6;
                break;
            case R.id.Button7:
                CellId=7;
                break;
            case R.id.Button8:
                CellId=8;
                break;
            case R.id.Button9:
                CellId=9;
                break;
        }
        //PlayGame(CellId,Selected);
        myRef.child("Playing").child(PlayerSession).child("CellId:"+CellId).setValue(BeforeAt(MyEmail));

    }

    //int chances=0;
    int ActivePlayer=1;//1-For player 1,2- For player 2
    ArrayList<Integer> Player1=new ArrayList<Integer>();
    ArrayList<Integer> Player2=new ArrayList<Integer>();
    //ArrayList<Integer>Empty=new ArrayList<Integer>();

    /*private Runnable mRunnable =new Runnable() {
        @Override
        public void run() {
            whenDone();
        }
    };

    void PlayGame(int Id,Button selected)
    {
        if(ActivePlayer==1)
        {
            selected.setBackgroundColor(Color.GREEN);
            selected.setText("X");
            Player1.add(Id);
            //ActivePlayer=2;
            //chances=chances+1;
            /*if(chances==9)
            {
                Toast.makeText(this,"Match Draw",Toast.LENGTH_LONG).show();
                ActivePlayer=1;
                mHandler.postDelayed(mRunnable,3000);

            }
            else if(chances>0)
            {
                CheckWinner();
            }
        }
        else if(ActivePlayer==2)
        {
            selected.setBackgroundColor(Color.CYAN);
            selected.setText("0");
            Player2.add(Id);
            //ActivePlayer=1;
            /*chances=chances+1;
            if(chances==9)
            {
                Toast.makeText(this,"Match Draw",Toast.LENGTH_LONG).show();
                ActivePlayer=1;
                mHandler.postDelayed(mRunnable,3000);

            }
            else if(chances>0)
                CheckWinner();
        }
        selected.setEnabled(false);//To insure,Once button is selected, again it sould not be selected
            CheckWinner();
    }

    void CheckWinner()
    {

        int Win=0;
        //For rows
        if(Player1.contains(1)&&Player1.contains(2)&&Player1.contains(3))
        {
            Win=1;
        }
        if(Player2.contains(1)&&Player2.contains(2)&&Player2.contains(3))
        {
            Win=2;
        }
        if(Player1.contains(4)&&Player1.contains(5)&&Player1.contains(6))
        {
            Win=1;
        }
        if(Player2.contains(4)&&Player2.contains(5)&&Player2.contains(6))
        {
            Win=2;
        }
        if(Player1.contains(7)&&Player1.contains(8)&&Player1.contains(9))
        {
            Win=1;
        }
        if(Player2.contains(7)&&Player2.contains(8)&&Player2.contains(9))
        {
            Win=2;
        }
        //For Columns
        if(Player1.contains(1)&&Player1.contains(4)&&Player1.contains(7))
        {
            Win=1;
        }
        if(Player2.contains(1)&&Player2.contains(4)&&Player2.contains(7))
        {
            Win=2;
        }
        if(Player1.contains(2)&&Player1.contains(5)&&Player1.contains(8))
        {
            Win=1;
        }
        if(Player2.contains(2)&&Player2.contains(5)&&Player2.contains(8))
        {
            Win=2;
        }
        if(Player1.contains(3)&&Player1.contains(6)&&Player1.contains(9))
        {
            Win=1;
        }
        if(Player2.contains(3)&&Player2.contains(6)&&Player2.contains(9))
        {
            Win=2;
        }

        if(Win!=0)
        {
            if(Win==1)
            {
                Toast.makeText(this,"Player1 is Winner",Toast.LENGTH_LONG).show();
                //ActivePlayer=1;
                //mHandler.postDelayed(mRunnable,3000);
            }
            else
            {
                Toast.makeText(this,"Player2 is Winner",Toast.LENGTH_LONG).show();
                //ActivePlayer=1;
                //mHandler.postDelayed(mRunnable,3000);
            }
        }
        //if(ActivePlayer==2)
            //AutoPlay();
    }

    /*void whenDone()
    {
        //chances=0;
        for(int i=1;i<=9;i++) {
            switch (i) {
                case 1:
                    Button SelectedButton1 = (Button) findViewById(R.id.Button1);
                    SelectedButton1.setBackgroundColor(Color.WHITE);
                    SelectedButton1.setEnabled(true);
                    SelectedButton1.setText("1");
                    break;
                case 2:
                    Button SelectedButton2 = (Button) findViewById(R.id.Button2);
                    SelectedButton2.setBackgroundColor(Color.WHITE);
                    SelectedButton2.setEnabled(true);
                    SelectedButton2.setText("2");
                    break;
                case 3:
                    Button SelectedButton3 = (Button) findViewById(R.id.Button3);
                    SelectedButton3.setBackgroundColor(Color.WHITE);
                    SelectedButton3.setEnabled(true);
                    SelectedButton3.setText("3");
                    break;
                case 4:
                    Button SelectedButton4 = (Button) findViewById(R.id.Button4);
                    SelectedButton4.setBackgroundColor(Color.WHITE);
                    SelectedButton4.setEnabled(true);
                    SelectedButton4.setText("4");
                    break;
                case 5:
                    Button SelectedButton5 = (Button) findViewById(R.id.Button5);
                    SelectedButton5.setBackgroundColor(Color.WHITE);
                    SelectedButton5.setEnabled(true);
                    SelectedButton5.setText("5");
                    break;
                case 6:
                    Button SelectedButton6 = (Button) findViewById(R.id.Button6);
                    SelectedButton6.setBackgroundColor(Color.WHITE);
                    SelectedButton6.setEnabled(true);
                    SelectedButton6.setText("6");
                    break;
                case 7:
                    Button SelectedButton7 = (Button) findViewById(R.id.Button7);
                    SelectedButton7.setBackgroundColor(Color.WHITE);
                    SelectedButton7.setEnabled(true);
                    SelectedButton7.setText("7");
                    break;
                case 8:
                    Button SelectedButton8 = (Button) findViewById(R.id.Button8);
                    SelectedButton8.setBackgroundColor(Color.WHITE);
                    SelectedButton8.setEnabled(true);
                    SelectedButton8.setText("8");
                    break;
                case 9:
                    Button SelectedButton9 = (Button) findViewById(R.id.Button9);
                    SelectedButton9.setBackgroundColor(Color.WHITE);
                    SelectedButton9.setEnabled(true);
                    SelectedButton9.setText("9");
                    break;
                default:
                    Button SelectedButton10 = (Button) findViewById(R.id.Button3);
                    SelectedButton10.setBackgroundColor(Color.WHITE);
                    break;
            }
        }
        Player1.clear();
        Player2.clear();
        Empty.clear();
    }


    void AutoPlay(int CellId)
    {
        //ArrayList<Integer>Empty=new ArrayList<Integer>();
        /*Empty.clear();
        for(int i=1;i<=9;i++)
        {
            if(!(Player1.contains(i)||Player2.contains(i)))
            {
                Empty.add(i);
            }
        }

        Random r=new Random();
        int RandIndex=r.nextInt(Empty.size()-0)+0;//if Size=3 select(0,1,2)
        int CellId=Empty.get(RandIndex);
        Button SelectedButton;
        switch(CellId)
        {
            case 1:
                SelectedButton=(Button)findViewById(R.id.Button1);
                break;
            case 2:
                SelectedButton=(Button)findViewById(R.id.Button2);
                break;
            case 3:
                SelectedButton=(Button)findViewById(R.id.Button3);
                break;
            case 4:
                SelectedButton=(Button)findViewById(R.id.Button4);
                break;
            case 5:
                SelectedButton=(Button)findViewById(R.id.Button5);
                break;
            case 6:
                SelectedButton=(Button)findViewById(R.id.Button6);
                break;
            case 7:
                SelectedButton=(Button)findViewById(R.id.Button7);
                break;
            case 8:
                SelectedButton=(Button)findViewById(R.id.Button8);
                break;
            case 9:
                SelectedButton=(Button)findViewById(R.id.Button9);
                break;
            default:
                SelectedButton=(Button)findViewById(R.id.Button1);
                break;
        }
        PlayGame(CellId,SelectedButton);
    }
}
*/